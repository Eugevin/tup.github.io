"use strict";

function tUP() {

  let tups = document.querySelectorAll('.tup');

  tups.forEach(tup => {

    // split and null

    let tupSpans = tup.textContent.split('');
    tup.textContent = '';

    tupSpans.forEach(item => {
      tup.innerHTML += `<span>${item}</span>`;
    });

    // all items in array

    if (tup.getAttribute('tup-show') == 'default') {
      tupShowDefault();
    } else if (tup.getAttribute('tup-show') == 'smooth') {
      tupShowSmooth();
    } else {
      tupShowDefault();
    };

    function tupShowDefault() {
      let spanItems = tup.querySelectorAll('span');

      for (let i = 0; i < spanItems.length; i++) {
        setTimeout(() => {
          spanItems[i].classList.add('tup__item');
        }, tupTimer() * i);
      };
    };

    function tupShowSmooth() {
      let spanItems = tup.querySelectorAll('span');

      for (let i = 0; i < spanItems.length; i++) {
        window.addEventListener('scroll', () => {
          if (spanItems[i].getBoundingClientRect().top < window.innerHeight / 1.2) {
            setTimeout(() => {
              spanItems[i].classList.add('tup__item');
            }, tupTimer() * i);
          };
        });
      };
    };

    function tupTimer() {
      let tupSpeed;

      if (tupSpeed = tup.hasAttribute('tup-speed')) {
        return tup.getAttribute('tup-speed');
      } else {
        return 100;
      };
    };
  });
};